"use client";
import React, { useEffect, useState, useRef } from "react";
import { io } from "socket.io-client";
import InteractiveHeatmap from "./interactiveheatmap";
import Toolbar from "./toolbar";
import styles from "./page.module.css";
import defaultWiReSensConfig from "./constants";
import { Button } from "@/components/ui/button";
import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { AppSidebar } from "@/components/app-sidebar";
import { AlignVerticalJustifyEnd } from "lucide-react";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
// Function to generate a 10x10 array with random values
const generateRandomArray = (rows, cols) => {
  const array = [];
  for (let i = 0; i < cols; i++) {
    const row = [];
    for (let j = 0; j < rows; j++) {
      row.push(0);
    }
    array.push(row);
  }
  return array;
};

const cloneFrame = (frame) => frame.map((row) => [...row]);

const medianFrame = (frames) => {
  if (!frames.length) return null;

  const rows = frames[0].length;
  const cols = frames[0][0].length;
  const median = [];

  for (let row = 0; row < rows; row++) {
    const medianRow = [];
    for (let col = 0; col < cols; col++) {
      const values = frames
        .map((frame) => frame[row]?.[col])
        .filter((value) => Number.isFinite(value))
        .sort((a, b) => a - b);
      const mid = Math.floor(values.length / 2);
      medianRow.push(
        values.length % 2 === 0
          ? (values[mid - 1] + values[mid]) / 2
          : values[mid]
      );
    }
    median.push(medianRow);
  }

  return median;
};

const SENSOR_RENDER_INTERVAL_MS = 100;

const Home = () => {
  const [WiSensConfig, setWiSensConfig] = useState(defaultWiReSensConfig);
  const [selectMode, setSelectMode] = useState(false);
  const [eraseMode, setEraseMode] = useState(false);
  const [adcMode, setAdcMode] = useState(false);
  const [normalizeMode, setNormalizeMode] = useState(false);
  const [contactMode, setContactMode] = useState(false);
  const [contactScale, setContactScale] = useState(1);
  const [baselineCaptureStatus, setBaselineCaptureStatus] = useState(null);
  const [sensorBaselines, setSensorBaselines] = useState({});
  const [connecting, setConnecting] = useState(false);
  const [recording, setRecording] = useState(false);
  const [stepCount, setStepCount] = useState(0);
  const [socket, setSocket] = useState(null);
  const interactiveHeatmapRefs = useRef({}); // Store refs dynamically
  const hiddenFileInputRefs = useRef({});
  const hiddenFileInput2Refs = useRef({});
  const sensorDivRefs = useRef({});
  const baselineSamplesRef = useRef({});
  const baselineCaptureRef = useRef({ active: false, remaining: 0, total: 30 });
  const pendingSensorDataRef = useRef(null);
  const sensorRenderTimerRef = useRef(null);
  const lastSensorRenderAtRef = useRef(0);
  const [open, setOpen] = useState(false);
  const [calibrating, setCalibrating] = useState(false);

  const defaultSensors = {};
  const defaultDims = {};
  defaultWiReSensConfig.sensors.forEach((sensorConfig) => {
    const numReadWires =
      sensorConfig.endCoord[0] - sensorConfig.startCoord[0] + 1;
    const numGroundWires =
      sensorConfig.endCoord[1] - sensorConfig.startCoord[1] + 1;
    defaultSensors[sensorConfig.id] = generateRandomArray(
      numReadWires,
      numGroundWires
    );
    defaultDims[sensorConfig.id] = [numReadWires, numGroundWires];
    interactiveHeatmapRefs.current[sensorConfig.id] =
      interactiveHeatmapRefs.current[sensorConfig.id] || React.createRef();
    hiddenFileInputRefs.current[sensorConfig.id] =
      hiddenFileInputRefs.current[sensorConfig.id] || React.createRef();
    hiddenFileInput2Refs.current[sensorConfig.id] =
      hiddenFileInput2Refs.current[sensorConfig.id] || React.createRef();
    sensorDivRefs.current[sensorConfig.id] =
      sensorDivRefs.current[sensorConfig.id] || React.createRef();
  });
  const [sensors, setSensors] = useState(defaultSensors);
  const [sensorDims, setSensorDims] = useState(defaultDims);
  const [acks, setAcks] = useState(defaultWiReSensConfig.sensors.map(() => false));

  const onSelectNodesClick = () => {
    setSelectMode(!selectMode);
  };

  const onEraseModeClick = () => {
    setEraseMode(!eraseMode);
  };

  const onAdcModeClick = () => {
    setAdcMode(!adcMode);
  };

  const onNormalizeModeClick = () => {
    setNormalizeMode((prev) => !prev);
    setContactMode(false);
  };

  const onContactModeClick = () => {
    if (contactMode || Object.keys(sensorBaselines).length > 0) {
      setContactMode((prev) => !prev);
      setNormalizeMode(false);
    }
  };

  const startBaselineCapture = () => {
    baselineSamplesRef.current = {};
    baselineCaptureRef.current = { active: true, remaining: 30, total: 30 };
    setBaselineCaptureStatus({ remaining: 30, total: 30 });
    setContactMode(false);

    if (!recording && socket) {
      socket.emit("startViz", WiSensConfig);
      setRecording(true);
      setConnecting(true);
    }
  };

  const updateSensorObjects = (config) => {
    // Initialize default sensors based on the loaded config
    // Use the current sensors and dims as the base
    const updatedSensors = { ...sensors };
    const updatedDims = { ...sensorDims };
    config.sensors.forEach((sensorConfig) => {
      const numReadWires =
        sensorConfig.endCoord[0] - sensorConfig.startCoord[0] + 1;
      const numGroundWires =
        sensorConfig.endCoord[1] - sensorConfig.startCoord[1] + 1;
      // Only initialize if it's a new device or dimensions are changing
      console.log(updatedSensors[sensorConfig.id]);
      console.log(updatedDims[sensorConfig.id]);
      console.log(numReadWires, numGroundWires);
      if (
        !updatedSensors[sensorConfig.id] ||
        updatedDims[sensorConfig.id][0] != numReadWires ||
        updatedDims[sensorConfig.id][1] != numGroundWires
      ) {
        console.log("Updating sensor ", sensorConfig.id);
        updatedSensors[sensorConfig.id] = generateRandomArray(
          numReadWires,
          numGroundWires
        );
        updatedDims[sensorConfig.id] = [numReadWires, numGroundWires];
      }
      interactiveHeatmapRefs.current[sensorConfig.id] =
        interactiveHeatmapRefs.current[sensorConfig.id] || React.createRef();
      hiddenFileInputRefs.current[sensorConfig.id] =
        hiddenFileInputRefs.current[sensorConfig.id] || React.createRef();
      hiddenFileInput2Refs.current[sensorConfig.id] =
        hiddenFileInput2Refs.current[sensorConfig.id] || React.createRef();
      sensorDivRefs.current[sensorConfig.id] =
        sensorDivRefs.current[sensorConfig.id] || React.createRef();
    });
    setSensorDims(updatedDims);
    setSensors(updatedSensors);
    setWiSensConfig(config);
    setAcks(config.sensors.map(() => false));
    setRecording(false);
    setConnecting(false);
    setContactMode(false);
    setSensorBaselines({});
    setBaselineCaptureStatus(null);
    baselineSamplesRef.current = {};
    baselineCaptureRef.current = { active: false, remaining: 0, total: 30 };
  };

  const handleFileChange = (event) => {
    const file = event.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        const config = JSON.parse(e.target.result);
        updateSensorObjects(config);
      };
      reader.readAsText(file);
    }
  };

  useEffect(() => {
    const localIp = WiSensConfig.vizOptions.localIp
      ? config.vizOptions.localIp
      : "127.0.0.1";

    const newSocket = io(`http://${localIp}:5328`);

    newSocket.on("connect", () => {
      console.log("Connected to server");
    });

    newSocket.on("disconnect", () => {
      console.log("Disconnected from server");
    });

    const flushSensorRender = () => {
      if (pendingSensorDataRef.current) {
        setSensors(pendingSensorDataRef.current);
        pendingSensorDataRef.current = null;
        lastSensorRenderAtRef.current = Date.now();
      }
      sensorRenderTimerRef.current = null;
    };

    const scheduleSensorRender = (dataObj) => {
      pendingSensorDataRef.current = dataObj;
      const elapsed = Date.now() - lastSensorRenderAtRef.current;

      if (elapsed >= SENSOR_RENDER_INTERVAL_MS && !sensorRenderTimerRef.current) {
        flushSensorRender();
        return;
      }

      if (!sensorRenderTimerRef.current) {
        sensorRenderTimerRef.current = window.setTimeout(
          flushSensorRender,
          Math.max(SENSOR_RENDER_INTERVAL_MS - elapsed, 0)
        );
      }
    };

    newSocket.on("sensor_data", (data) => {
      const dataObj = JSON.parse(data);
      scheduleSensorRender(dataObj);
      setConnecting(false);

      const capture = baselineCaptureRef.current;
      if (capture.active) {
        Object.entries(dataObj).forEach(([id, frame]) => {
          if (!baselineSamplesRef.current[id]) {
            baselineSamplesRef.current[id] = [];
          }
          baselineSamplesRef.current[id].push(cloneFrame(frame));
        });

        const remaining = capture.remaining - 1;
        baselineCaptureRef.current = {
          ...capture,
          remaining,
          active: remaining > 0,
        };
        setBaselineCaptureStatus({
          remaining: Math.max(remaining, 0),
          total: capture.total,
        });

        if (remaining <= 0) {
          const baselines = {};
          Object.entries(baselineSamplesRef.current).forEach(([id, frames]) => {
            const baseline = medianFrame(frames);
            if (baseline) {
              baselines[id] = baseline;
            }
          });
          setSensorBaselines(baselines);
          setContactMode(true);
          setNormalizeMode(false);
          setBaselineCaptureStatus(null);
          baselineSamplesRef.current = {};
        }
      }
    });

    newSocket.on("step", (count) => {
      setStepCount(count);
    });

    newSocket.on("connection_status", (msg) => {
      let status = msg["connected"];
      let id = msg["id"];
      console.log("Connection Status Message Received");
      if (status) {
        const index = WiSensConfig.sensors.findIndex(
          (sensor) => sensor.id === id
        );
        setAcks((prevAcks) => {
          const updatedAcks = [...prevAcks];
          updatedAcks[index] = true;
          return updatedAcks;
        });
        setConnecting(false);
      }
    });

    newSocket.on("calibration_done", (data) => {
      console.log("Calibration Done");
      let sensor_id = data.id;
      let resistance = data.value;
      // Update WiSensConfig when calibration is done
      setWiSensConfig((prevConfig) => {
        const foundDevice = prevConfig.sensors.find(
          (sensor) => sensor.id === sensor_id
        );

        if (foundDevice) {
          const newDevice = { ...foundDevice, resistance };

          const updatedSensors = prevConfig.sensors
            .map((sensor) => (sensor.id === sensor_id ? newDevice : sensor))
            .sort((a, b) => a.id - b.id);

          return { ...prevConfig, sensors: updatedSensors };
        }

        return prevConfig; // If sensor not found, return previous config
      });

      setCalibrating(false);
    });

    setSocket(newSocket);

    const stopActiveStream = () => {
      newSocket.emit("stopViz");
    };

    window.addEventListener("beforeunload", stopActiveStream);

    // Cleanup function to stop the live stream and close the socket when unmounting
    return () => {
      if (sensorRenderTimerRef.current) {
        window.clearTimeout(sensorRenderTimerRef.current);
        sensorRenderTimerRef.current = null;
      }
      window.removeEventListener("beforeunload", stopActiveStream);
      stopActiveStream();
      newSocket.disconnect();
    };
  }, []); // Empty dependency array ensures this runs only once when mounted

  useEffect(() => {
    if (acks.every((ack) => ack === true)) {
      setConnecting(false);
    }
  }, [acks]);

  const handleClick = (hiddenFile) => {
    hiddenFile.current.click();
  };

  const onConnectDevices = () => {
    if (!socket) return;

    if (recording) {
      socket.emit("stopViz");
      setRecording(false);
      setConnecting(false);
      setAcks(WiSensConfig.sensors.map(() => false));
    } else if (!connecting) {
      socket.emit("startViz", WiSensConfig);
      setRecording(true);
      setConnecting(true);
    }
  };

  const onCalibrate = (sensorId) => {
    setCalibrating(true);
    socket.emit("calibrate", sensorId);
  };

  const onPlay = (settings) => {
    console.log("start replay");
    socket.emit("replay", settings);
  };

  const onPause = () => {
    console.log("stop replay");
    if (!socket) return;
    socket.emit("stopViz");
    setRecording(false);
    setConnecting(false);
    setContactMode(false);
    setSensorBaselines({});
    setBaselineCaptureStatus(null);
    baselineSamplesRef.current = {};
    baselineCaptureRef.current = { active: false, remaining: 0, total: 30 };
  };

  const toggleDrawer = () => setOpen(!open);

  const handleDeleteDevice = (id) => {
    setWiSensConfig({
      ...WiSensConfig,
      sensors: WiSensConfig.sensors.filter((device) => device.id !== id),
    });
  };

  const handleAddDevice = () => {
    const newDevice = {
      id: WiSensConfig.sensors.length + 1,
      protocol: "ble",
      serialPort: "",
      deviceName: "New Device",
      startCoord: [0, 0],
      endCoord: [7, 7],
      resistance: 1000,
      intermittent: { enabled: false, p: 0, d: 0 },
      outlineImage: "",
    };
    setWiSensConfig({
      ...WiSensConfig,
      sensors: [...WiSensConfig.sensors, newDevice],
    });
  };

  return (
    <SidebarProvider defaultOpen={false} open={open}>
      <div className={styles.pageDiv}>
        <Toolbar
          onPlay={onPlay}
          onPause={onPause}
          config={WiSensConfig}
          onConnectDevices={onConnectDevices}
          onSave={updateSensorObjects}
          onLoadConfig={handleFileChange}
          onSelectNodes={onSelectNodesClick}
          onRemoveNodes={onEraseModeClick}
          onAdcMode={onAdcModeClick}
          onNormalizeMode={onNormalizeModeClick}
          onCaptureBaseline={startBaselineCapture}
          onContactMode={onContactModeClick}
          contactScale={contactScale}
          onContactScaleChange={setContactScale}
          toggleDrawer={toggleDrawer}
          connected={recording}
          connecting={connecting}
          eraseMode={eraseMode}
          selectMode={selectMode}
          adcMode={adcMode}
          normalizeMode={normalizeMode}
          contactMode={contactMode}
          hasBaseline={Object.keys(sensorBaselines).length > 0}
          baselineCaptureStatus={baselineCaptureStatus}
        ></Toolbar>
        <div
          style={{
            paddingLeft: "10%",
            paddingTop: "20px",
            fontSize: "large",
          }}
        >
          {/* <b>{`Step Count: ${stepCount}`}</b> */}
        </div>
        <div className={styles.sensorDiv}>
          {WiSensConfig.sensors.map((sensorId) => (
            <div key={sensorId.id} className={styles.heatmapContainer}>
              <div className={styles.sensorControls}>
                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <span>
                        <button
                          disabled={calibrating}
                          className={styles.toolbarButton}
                          onClick={() => {
                            onCalibrate(sensorId.id);
                          }}
                        >
                          Calibrate
                        </button>
                      </span>
                    </TooltipTrigger>
                    {calibrating && (
                      <TooltipContent>Device is Calibrating</TooltipContent>
                    )}
                  </Tooltip>
                </TooltipProvider>
                <button
                  className={styles.toolbarButton}
                  onClick={() => {
                    interactiveHeatmapRefs.current[
                      sensorId.id
                    ].current.setShape();
                  }}
                >
                  Toggle Shape
                </button>
                <button
                  className={styles.toolbarButton}
                  onClick={() => {
                    interactiveHeatmapRefs.current[
                      sensorId.id
                    ].current.saveLayout();
                  }}
                >
                  Save Layout
                </button>
                <button
                  className={styles.toolbarButton}
                  onClick={() => {
                    handleClick(hiddenFileInputRefs.current[sensorId.id]);
                  }}
                >
                  Load Layout
                </button>
                <input
                  type="file"
                  ref={hiddenFileInputRefs.current[sensorId.id]} // ADDED
                  onChange={(event) => {
                    interactiveHeatmapRefs.current[
                      sensorId.id
                    ].current.loadLayout(event);
                  }}
                  style={{ display: "none" }}
                />
                <button
                  className={styles.toolbarButton}
                  onClick={() => {
                    handleClick(hiddenFileInput2Refs.current[sensorId.id]);
                  }}
                >
                  Upload Image
                </button>
                <input
                  type="file"
                  ref={hiddenFileInput2Refs.current[sensorId.id]}
                  onChange={(event) => {
                    interactiveHeatmapRefs.current[
                      sensorId.id
                    ].current.uploadBackgroundImage(event);
                  }}
                  style={{ display: "none" }}
                />
                <div
                  className={styles.sensorTitle}
                >{`${sensorId.deviceName}`}</div>
              </div>
              <div
                ref={sensorDivRefs.current[sensorId.id]}
                className={`${styles.interactiveHeatmapDiv} ${styles.noselect}`}
              >
                <InteractiveHeatmap
                  ref={interactiveHeatmapRefs.current[sensorId.id]}
                  data={sensors[sensorId.id]}
                  dim={sensorDims[sensorId.id]}
                  sensorDivRef={sensorDivRefs.current[sensorId.id]}
                  pitch={WiSensConfig.vizOptions.pitch}
                  selectMode={selectMode}
                  eraseMode={eraseMode}
                  setSelectMode={setSelectMode}
                  showADC={adcMode}
                  normalizeView={normalizeMode}
                  contactView={contactMode}
                  contactScale={contactScale}
                  baseline={sensorBaselines[sensorId.id]}
                ></InteractiveHeatmap>
              </div>
            </div>
          ))}
        </div>
      </div>
      <AppSidebar
        Config={WiSensConfig}
        handleDeleteDevice={handleDeleteDevice}
        updateSensorObjects={updateSensorObjects}
        socket={socket}
        connected={recording}
      />
    </SidebarProvider>
  );
};

export default Home;
