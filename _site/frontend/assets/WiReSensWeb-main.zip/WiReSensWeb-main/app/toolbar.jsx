import React, { useRef } from "react";
import styles from "./Toolbar.module.css";
import { Button } from "@/components/ui/button";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { WiFiSettings } from "./wifiSettings";
import { ReplayPanel } from "./replayPanel";
import { Wifi, Repeat } from "lucide-react";

const CONTACT_SCALE_MIN = 0.01;
const CONTACT_SCALE_MAX = 100;
const CONTACT_SCALE_LOG_MIN = Math.log10(CONTACT_SCALE_MIN);
const CONTACT_SCALE_LOG_MAX = Math.log10(CONTACT_SCALE_MAX);

const clampContactScale = (value) => {
  if (!Number.isFinite(value)) return 1;
  return Math.min(Math.max(value, CONTACT_SCALE_MIN), CONTACT_SCALE_MAX);
};

const formatContactScale = (value) => {
  const safeValue = clampContactScale(value);
  if (safeValue < 1) return safeValue.toFixed(2);
  if (safeValue < 10) return safeValue.toFixed(2).replace(/\.?0+$/, "");
  return safeValue.toFixed(0);
};

const Toolbar = ({
  onPlay,
  onPause,
  config,
  onSave,
  onLoadConfig,
  onConnectDevices,
  onSelectNodes,
  onRemoveNodes,
  connected,
  connecting,
  onAdcMode,
  onNormalizeMode,
  onCaptureBaseline,
  onContactMode,
  contactScale,
  onContactScaleChange,
  toggleDrawer,
  selectMode,
  eraseMode,
  adcMode,
  normalizeMode,
  contactMode,
  hasBaseline,
  baselineCaptureStatus,
}) => {
  const hiddenFileInputConfig = useRef(null);
  const safeContactScale = clampContactScale(contactScale);
  const contactScaleSliderValue = Math.log10(safeContactScale);

  const handleConfigClick = (event) => {
    hiddenFileInputConfig.current.click();
  };

  const handleContactScaleChange = (event) => {
    const logValue = Number(event.target.value);
    const nextScale = 10 ** logValue;
    onContactScaleChange(Number(nextScale.toFixed(4)));
  };

  return (
    <div
      className={`${styles.toolbar} no-select`}
      style={{
        display: "flex",
        alignItems: "center",
        position: "relative",
        flexWrap: "wrap",
        gap: "10px",
      }}
    >
      <Button onClick={handleConfigClick}>Load Config</Button>
      <input
        type="file"
        ref={hiddenFileInputConfig}
        accept=".json"
        onChange={onLoadConfig}
        style={{ display: "none" }}
      />
      <Button
        onClick={onConnectDevices}
        style={{ backgroundColor: connected ? "#838181" : "#000000" }}
      >
        {connected ? "Stop Recording" : "Record"}
      </Button>
      <div style={{ display: connecting ? "block" : "none" }}>
        Connecting...
      </div>
      <Popover>
        <PopoverTrigger asChild>
          <Button size="icon">
            <Repeat className="w-4 h-4" />
          </Button>
        </PopoverTrigger>
        <PopoverContent style={{ width: "400px" }}>
          <ReplayPanel
            config={config}
            onPlay={onPlay}
            onPause={onPause}
          ></ReplayPanel>
        </PopoverContent>
      </Popover>
      <Button
        onClick={onSelectNodes}
        style={{ backgroundColor: selectMode ? "#838181" : "#000000" }}
      >
        Select Nodes
      </Button>
      <Button
        onClick={onRemoveNodes}
        style={{ backgroundColor: eraseMode ? "#838181" : "#000000" }}
      >
        Remove Nodes
      </Button>

      <Button
        onClick={onAdcMode}
        style={{ backgroundColor: adcMode ? "#838181" : "#000000" }}
      >
        Show Values
      </Button>

      <Button
        onClick={onNormalizeMode}
        style={{ backgroundColor: normalizeMode ? "#838181" : "#000000" }}
      >
        Normalize View
      </Button>

      <Button onClick={onCaptureBaseline}>
        {baselineCaptureStatus
          ? `Baseline ${baselineCaptureStatus.total - baselineCaptureStatus.remaining}/${baselineCaptureStatus.total}`
          : "Set Baseline"}
      </Button>

      <Button
        onClick={onContactMode}
        disabled={!hasBaseline && !contactMode}
        style={{ backgroundColor: contactMode ? "#838181" : "#000000" }}
      >
        Contact View
      </Button>

      <label className={styles.sliderControl}>
        <span>Scale ÷ {formatContactScale(safeContactScale)}</span>
        <input
          type="range"
          min={CONTACT_SCALE_LOG_MIN}
          max={CONTACT_SCALE_LOG_MAX}
          step="0.01"
          value={contactScaleSliderValue}
          onChange={handleContactScaleChange}
        />
      </label>

      <Popover>
        <PopoverTrigger asChild>
          <Button size="icon">
            <Wifi className="w-4 h-4" />
          </Button>
        </PopoverTrigger>
        <PopoverContent style={{ width: "400px" }}>
          <WiFiSettings config={config} onSave={onSave} />
        </PopoverContent>
      </Popover>

      <Button onClick={toggleDrawer}>
        Device Panel
      </Button>
    </div>
  );
};

export default Toolbar;
