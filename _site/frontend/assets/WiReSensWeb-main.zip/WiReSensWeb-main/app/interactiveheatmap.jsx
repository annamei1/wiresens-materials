// components/InteractiveHeatmap.js
import React, {
  useState,
  useRef,
  useEffect,
  useMemo,
  forwardRef,
  useImperativeHandle,
} from "react";
import styles from "./InteractiveHeatmap.module.css";
import { ResizableBox } from "react-resizable";
import Colorbar from "./colorbar";
import "react-resizable/css/styles.css";

const InteractiveHeatmap = forwardRef(
  (
    {
      data,
      dim,
      sensorDivRef,
      pitch,
      selectMode,
      eraseMode,
      setSelectMode,
      showADC,
      normalizeView = false,
      contactView = false,
      contactScale = 1,
      baseline = null,
    },
    ref
  ) => {
    const [dragging, setDragging] = useState(false);
    const [draggedNodes, setDraggedNodes] = useState(null);
    const [erasedNodes, setErasedNodes] = useState([]);
    const [dragCoords, setDragCoords] = useState(null);
    const [positions, setPositions] = useState({});
    const [bboxStart, setBboxStart] = useState(null);
    const [bboxEnd, setBboxEnd] = useState(null);
    const [isCircle, setIsCircle] = useState(false);
    const [templateDimensions, setTemplateDimensions] = useState({
      width: 0,
      height: 0,
    });
    const [templateOffset, setTemplateOffset] = useState({ top: 0, left: 0 });
    const onResize = (event, { size }) => {
      let deltaX = size.width - templateDimensions.width; //If greater than 0, x length grew, meaning we moved closer towards origin
      let deltaY = size.height - templateDimensions.height; //If greater than 0, y length grew, meaning we moved closer towards origin
      setTemplateDimensions(size);
      setTemplateOffset({
        top: templateOffset.top - deltaY,
        left: templateOffset.left - deltaX,
      });
    };
    const containerRef = useRef(null);
    const [outlineImage, setOutlineImage] = useState(null); // Store uploaded image

    const marginNodes = 2; //Number of nodes to leave for "dragging room" on top and bottom of heatmap

    const [cellSize, setCellSize] = useState(0);
    const scaleFactor = outlineImage ? 2 : 1;
    const CONTACT_COLOR_MAX = 2500;
    const CONTACT_NOISE_SCALE = 80;
    const CONTACT_SMOOTHING_ALPHA = 0.2;
    const RAW_DISPLAY_SMOOTHING_ALPHA = 0.2;
    const RAW_DISPLAY_HISTORY_LENGTH = 3;
    const previousContactFrameRef = useRef(null);
    const previousDisplayFrameRef = useRef(null);
    const displayHistoryRef = useRef([]);

    useEffect(() => {
      const element = sensorDivRef.current;
      if (!element) return;

      const updateLayout = () => {
        const numRows = dim[1];
        const numCols = dim[0];
        const { clientWidth, clientHeight } = element;
        if (!clientWidth || !clientHeight || !numRows || !numCols) return;

        const availableHeight = Math.max(0, clientHeight - 60);
        const estNodeWidth =
          clientWidth / scaleFactor / (numCols + 2 * marginNodes);
        const estNodeHeight = availableHeight / (numRows + 2 * marginNodes);
        const thiscellSize = Math.max(1, Math.min(estNodeHeight, estNodeWidth));
        const renderedCellSize = Math.max(1, thiscellSize - pitch);

        setCellSize(renderedCellSize);
        setTemplateDimensions({
          width: thiscellSize * numCols,
          height: thiscellSize * numRows,
        });
        setTemplateOffset({
          top: (clientHeight - thiscellSize * numRows) / 2,
          left: clientWidth / 2,
        });
      };

      updateLayout();

      const resizeObserver = new ResizeObserver(updateLayout);
      resizeObserver.observe(element);
      window.addEventListener("resize", updateLayout);

      return () => {
        resizeObserver.disconnect();
        window.removeEventListener("resize", updateLayout);
      };
    }, [sensorDivRef, dim, pitch, scaleFactor]);

    useEffect(() => {
      const initialPositions = {};
      const numRows = dim[1];
      const numCols = dim[0];
      if (!sensorDivRef.current || !cellSize) return;
      const { clientWidth, clientHeight } = sensorDivRef.current;
      for (let rowIndex = 0; rowIndex < numRows; rowIndex++) {
        for (let colIndex = 0; colIndex < numCols; colIndex++) {
          initialPositions[`${rowIndex}-${colIndex}`] = {
            x:
              colIndex * (cellSize + pitch) +
              (clientWidth / scaleFactor - (cellSize + pitch) * numCols) / 2,
            y:
              rowIndex * (cellSize + pitch) +
              (clientHeight - (cellSize + pitch) * numRows) / 2,
          };
        }
      }
      setPositions(initialPositions);
    }, [cellSize, dim, pitch, scaleFactor, sensorDivRef]);

    const handleMouseDownCell = (row, col, event) => {
      if (eraseMode) {
        setErasedNodes((prevErased) => {
          return [...prevErased, `${row}-${col}`];
        });
      } else if (!selectMode) {
        setDragging(true);
        const { clientX, clientY } = event;
        const rect = containerRef.current.getBoundingClientRect();
        const x = clientX - rect.left;
        const y = clientY - rect.top;
        setDragCoords({ x, y });
        if (!draggedNodes) {
          setDraggedNodes([`${row}-${col}`]);
        }
      }
    };

    const handleMouseDownHeatmap = (event) => {
      if (selectMode) {
        const rect = containerRef.current.getBoundingClientRect();
        setDragging(true);
        setBboxStart({
          x: event.clientX - rect.left,
          y: event.clientY - rect.top,
        });
        setBboxEnd({
          x: event.clientX - rect.left,
          y: event.clientY - rect.top,
        });
      }
    };

    function getEncapsulatedNodes() {
      let boxLeft = Math.min(bboxStart.x, bboxEnd.x);
      let boxTop = Math.min(bboxStart.y, bboxEnd.y);
      let boxRight = Math.max(bboxStart.x, bboxEnd.x);
      let boxBottom = Math.max(bboxStart.y, bboxEnd.y);
      const encapsulatedNodes = [];

      Object.entries(positions).forEach(([nodeId, { x, y }]) => {
        const nodeLeft = x;
        const nodeRight = x + cellSize;
        const nodeTop = y;
        const nodeBottom = y + cellSize;

        // Check if the node is at least partially within the bounding box
        const isEncapsulated =
          nodeRight >= boxLeft &&
          nodeLeft <= boxRight &&
          nodeBottom >= boxTop &&
          nodeTop <= boxBottom;

        if (isEncapsulated) {
          encapsulatedNodes.push(nodeId);
        }
      });

      return encapsulatedNodes;
    }

    const saveLayout = () => {
      const layoutData = {
        positions,
        erasedNodes,
      };

      const blob = new Blob([JSON.stringify(layoutData, null, 2)], {
        type: "application/json",
      });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = "layout.json";
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    };

    const loadLayout = (event) => {
      const file = event.target.files[0];
      if (!file) return;

      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const layoutData = JSON.parse(e.target.result);
          if (layoutData.positions && layoutData.erasedNodes) {
            setPositions(layoutData.positions);
            setErasedNodes(layoutData.erasedNodes);
          } else {
            console.error("Invalid file format");
          }
        } catch (error) {
          console.error("Error reading file", error);
        }
      };
      reader.readAsText(file);
    };

    const uploadBackgroundImage = (event) => {
      const file = event.target.files[0];
      if (!file) return;

      const reader = new FileReader();
      reader.onload = (e) => {
        setOutlineImage(e.target.result); // Store base64 image
      };
      reader.readAsDataURL(file);
    };

    const setShape = () => {
      setIsCircle(!isCircle);
    };

    useImperativeHandle(ref, () => ({
      saveLayout,
      loadLayout,
      uploadBackgroundImage,
      setShape,
    }));

    const handleMouseUp = () => {
      setDragging(false);
      if (selectMode) {
        if (eraseMode) {
          setErasedNodes((prevErased) => {
            let newNodes = getEncapsulatedNodes();
            return [...prevErased, ...newNodes];
          });
        } else {
          setDraggedNodes(getEncapsulatedNodes());
        }
        setSelectMode(false);
      } else {
        setDraggedNodes(null);
      }
      setBboxEnd({});
      setBboxStart({});
      setDragCoords(null);
    };

    const handleMouseLeave = () => {
      setDragging(false);
      if (selectMode) {
        if (eraseMode) {
          setErasedNodes((prevErased) => {
            let newNodes = getEncapsulatedNodes();
            return [...prevErased, ...newNodes];
          });
        } else {
          setDraggedNodes(getEncapsulatedNodes());
        }
        setSelectMode(false);
      } else {
        setDraggedNodes(null);
      }
      setBboxEnd({});
      setBboxStart({});
      setDragCoords(null);
    };

    const handleMouseMove = (event) => {
      if (dragging && draggedNodes && !selectMode) {
        const { clientX, clientY } = event;
        const rect = containerRef.current.getBoundingClientRect();
        const x = clientX - rect.left;
        const y = clientY - rect.top;
        const deltaX = x - dragCoords.x;
        const deltaY = y - dragCoords.y;
        const updatedPositions = { ...positions };
        draggedNodes.forEach((nodeId) => {
          updatedPositions[nodeId].x += deltaX;
          updatedPositions[nodeId].y += deltaY;
        });
        setPositions(updatedPositions);
        setDragCoords({ x, y });
      } else if (dragging && selectMode) {
        const rect = containerRef.current.getBoundingClientRect();
        setBboxEnd({
          x: event.clientX - rect.left,
          y: event.clientY - rect.top,
        });
      }
    };

    const smoothFrame = (frame, previousFrame, alpha) => {
      if (!previousFrame) return frame;

      return frame.map((row, rowIndex) =>
        row.map((value, colIndex) => {
          const previousValue = previousFrame[rowIndex]?.[colIndex];
          if (!Number.isFinite(previousValue)) return value;
          return alpha * value + (1 - alpha) * previousValue;
        })
      );
    };

    const medianFromFrameHistory = (history) => {
      if (!history.length) return data;

      return history[history.length - 1].map((row, rowIndex) =>
        row.map((_, colIndex) => {
          const values = history
            .map((frame) => frame[rowIndex]?.[colIndex])
            .filter((value) => Number.isFinite(value))
            .sort((a, b) => a - b);
          return values[Math.floor(values.length / 2)] ?? 0;
        })
      );
    };

    const displayData = useMemo(() => {
      if (!contactView || !baseline) {
        previousContactFrameRef.current = null;
        displayHistoryRef.current = [
          ...displayHistoryRef.current.slice(-(RAW_DISPLAY_HISTORY_LENGTH - 1)),
          data,
        ];
        const medianFilteredFrame = medianFromFrameHistory(displayHistoryRef.current);
        const smoothedFrame = smoothFrame(
          medianFilteredFrame,
          previousDisplayFrameRef.current,
          RAW_DISPLAY_SMOOTHING_ALPHA
        );
        previousDisplayFrameRef.current = smoothedFrame;
        return smoothedFrame;
      }

      previousDisplayFrameRef.current = null;
      displayHistoryRef.current = [];
      const contactData = data.map((row, rowIndex) =>
        row.map((value, colIndex) => {
          const baselineValue = baseline[rowIndex]?.[colIndex];
          if (!Number.isFinite(baselineValue)) return 0;
          const contactValue = baselineValue - value;
          return Math.max(contactValue, 0);
        })
      );

      const smoothedFrame = smoothFrame(
        contactData,
        previousContactFrameRef.current,
        CONTACT_SMOOTHING_ALPHA
      );
      previousContactFrameRef.current = smoothedFrame;
      return smoothedFrame;
    }, [data, contactView, baseline]);

    const colorScale = useMemo(() => {
      const flatValues = displayData
        .flat()
        .filter((value) => Number.isFinite(value));

      if (flatValues.length === 0) {
        return { min: 0, max: 4096 };
      }

      if (contactView) {
        return { min: 0, max: CONTACT_COLOR_MAX };
      }

      if (!normalizeView) {
        return { min: 0, max: 4096 };
      }

      const unsaturatedValues = flatValues.filter(
        (value) => value > 0 && value < 4095
      );
      const values =
        unsaturatedValues.length >= Math.max(8, flatValues.length * 0.05)
          ? unsaturatedValues
          : flatValues;
      const sortedValues = [...values].sort((a, b) => a - b);
      const lowerIndex = Math.floor((sortedValues.length - 1) * 0.05);
      const upperIndex = Math.ceil((sortedValues.length - 1) * 0.95);
      const min = sortedValues[lowerIndex];
      const max = sortedValues[upperIndex];

      if (!Number.isFinite(min) || !Number.isFinite(max) || max <= min) {
        return { min: 0, max: 4096 };
      }

      return { min, max };
    }, [displayData, contactView, normalizeView]);

    const getColor = (displayValue) => {
      const safeContactScale =
        Number.isFinite(contactScale) && contactScale > 0 ? contactScale : 1;
      const scaledDisplayValue = contactView
        ? displayValue / safeContactScale
        : displayValue;
      const scaledValue =
        contactView || normalizeView
          ? ((Math.min(Math.max(scaledDisplayValue, colorScale.min), colorScale.max) -
              colorScale.min) /
              (colorScale.max - colorScale.min)) *
            4096
          : scaledDisplayValue;
      const hue = (1 - scaledValue / 4096) * 240;
      return `hsl(${hue}, 100%, 50%)`;
    };

    const getValueLabel = (value, rowIndex, colIndex) => {
      const baselineValue = baseline?.[rowIndex]?.[colIndex];
      const displayValue =
        contactView && Number.isFinite(baselineValue)
          ? baselineValue - value
          : value;
      return Math.round(displayValue);
    };

    const handleDragStart = (e) => {
      e.preventDefault();
    };

    const handleDrop = (e) => {
      e.preventDefault();
    };

    const getBoundingBoxStyle = () => {
      const left = Math.min(bboxStart.x, bboxEnd.x);
      const top = Math.min(bboxStart.y, bboxEnd.y);
      const width = Math.abs(bboxStart.x - bboxEnd.x);
      const height = Math.abs(bboxStart.y - bboxEnd.y);

      return {
        position: "absolute",
        left,
        top,
        width,
        height,
        border: "2px dashed blue",
        pointerEvents: "none",
        zIndex: 5,
      };
    };

    return (
      <div
        className={`${styles.heatmap} ${styles.noselect}`}
        ref={containerRef}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseDown={handleMouseDownHeatmap}
        onMouseLeave={handleMouseLeave}
      >
        {selectMode && bboxStart && <div style={getBoundingBoxStyle()} />}
        <Colorbar normalized={normalizeView} contact={contactView}></Colorbar>
        {data.map((row, rowIndex) => (
          <div key={rowIndex} className={styles.row}>
            {row.map((value, colIndex) => {
              const position = positions[`${rowIndex}-${colIndex}`];
              const nodeId = `${rowIndex}-${colIndex}`;
              return (
                <div
                  key={colIndex}
                  className={`${styles.cell}`}
                  style={{
                    backgroundColor:
                      draggedNodes && draggedNodes.includes(nodeId)
                        ? "aquamarine"
                        : getColor(displayData[rowIndex]?.[colIndex] ?? value),
                    position: "absolute",
                    left: position ? position.x : colIndex * cellSize,
                    top: position ? position.y : rowIndex * cellSize,
                    zIndex:
                      draggedNodes && draggedNodes.includes(nodeId) ? 1000 : 2,
                    cursor: dragging ? "grabbing" : "grab",
                    width: cellSize,
                    height: cellSize,
                    fontSize: Math.max(10, Math.min(18, cellSize * 0.45)),
                    borderRadius: isCircle ? "50%" : "0px",
                    display:
                      erasedNodes && erasedNodes.includes(nodeId)
                        ? "none"
                        : "flex",
                    alignItems: "center", // Centers text vertically
                    justifyContent: "center", // Centers text horizontally
                  }}
                  onMouseDown={(e) =>
                    handleMouseDownCell(rowIndex, colIndex, e)
                  }
                  onMouseEnter={(e) => {
                    e.target.style.border = "1px solid black";
                  }}
                  onMouseLeave={(e) => {
                    e.target.style.border = "none";
                  }}
                >
                  {showADC && (
                    <span>{getValueLabel(value, rowIndex, colIndex)}</span>
                  )}
                </div>
              );
            })}
          </div>
        ))}
        {outlineImage && (
          <ResizableBox
            style={{
              position: "absolute",
              top: templateOffset.top,
              left: templateOffset.left,
              zIndex: 1,
              userSelect: "none",
              // width: "50%",
              // height: (cellSize + pitch) * numRows,
            }}
            width={templateDimensions.width}
            height={templateDimensions.height}
            onResize={onResize}
            resizeHandles={["nw"]}
          >
            <img
              className={styles.noselect}
              style={{
                width: "100%",
                height: "100%",
                objectFit: "contain",
                position: "absolute",
                zIndex: -1,
              }}
              src={outlineImage}
            ></img>
          </ResizableBox>
        )}
      </div>
    );
  }
);

export default InteractiveHeatmap;
