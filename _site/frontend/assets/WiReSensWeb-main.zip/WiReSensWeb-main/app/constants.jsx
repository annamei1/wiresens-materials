const defaultWiReSensConfig = {
  "wifiOptions": {
    "tcp_ip": "",
    "port": 7001,
    "numNodes": 120,
    "ssid": "MLDEV",
    "password": ""
  },
  "readoutOptions": {
    "groundPins": [
      26,
      25,
      4,
      21,
      12
    ],
    "readPins": [
      27,
      33,
      15,
      32,
      14
    ],
    "adcPin": 34,
    "externalAdc": false
  },
  "sensors": [
    {
      "id": 1,
      "protocol": "serial",
      "serialPort": "/dev/cu.usbserial-0287BBE3",
      "deviceName": "Esp1",
      "startCoord": [
        0,
        0
      ],
      "endCoord": [
        31,
        31
      ],
      "resistance": 3,
      "intermittent": {
        "enabled": false,
        "p": 21,
        "d": 46
      },
      "outlineImage": "",
      "saturatedPercentage": 1,
      "duration": 60000
    }
  ],
  "serialOptions": {
    "baudrate": 250000,
    "numNodes": 120
  },
  "bleOptions": {
    "numNodes": 120
  },
  "espnowOptions": {
    "macAddress": [
      20,
      43,
      47,
      202,
      117,
      216
    ],
    "numNodes": 120
  },
  "vizOptions": {
    "pitch": 0,
    "localIp": "",
    "glove": true
  }
};

export default defaultWiReSensConfig;
